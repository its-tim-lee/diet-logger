import React from 'react';
import { PreviewHeader } from './components/PreviewHeader';
import { Carousel } from './components/Carousel';
import { CaptionCard } from './components/CaptionCard';
import { Footer } from './components/Footer';
import { PostData } from './types';

// Data derived from the user's prompt
const IMAGE_URL = 'https://lh3.googleusercontent.com/aida-public/AB6AXuCIhVyQIKkIkctOpq2oAQ__e-VvqQVeZ_veMyj5S50d3Dgjxkzn37YsPgFM9f0XkweIf_MYegqY59PIAyRPX7NIkAx-Kq00IglP069WxN7GLavKVL5Y1nZrUp89VoN8Y3f0sNf5lMW1dg-S_dcsbaIWDeI5cADiZAkHGmPrugfJeHaRpVyHFJ4SpowdpAuRabM3LGmJgb6gmRtpYS3Aew7GfgtPvw8s2-i5AzHAKiPMpU-0qHtSzEcIVe2x4Wqt2sgdiNHZlOIlwA';

const MOCK_DATA: PostData = {
  images: [
    {
      id: '1',
      url: IMAGE_URL,
      alt: 'Avocado toast with eggs',
    },
    {
      id: '2',
      url: IMAGE_URL,
      alt: 'Avocado toast with eggs - Variation',
      filter: 'hue-rotate(15deg) contrast(1.1)', // Simulating a different "edit" or filter
    },
    {
        id: '3',
        url: IMAGE_URL,
        alt: 'Avocado toast - BW',
        filter: 'grayscale(1)',
    }
  ],
  caption: 'Just crushed a healthy lunch! Hitting my protein goals for the day. 🌱🍳 Keeping it consistent with the routine.',
  hashtags: [
    '#HealthyLiving',
    '#FoodLogger',
    '#WellnessJourney',
    '#AvocadoLover'
  ]
};

const App: React.FC = () => {
  return (
    <div className="relative flex min-h-screen w-full flex-col max-w-md mx-auto overflow-hidden bg-background-light dark:bg-background-dark shadow-2xl">
      <PreviewHeader />
      
      <main className="flex-1 flex flex-col w-full">
        <Carousel images={MOCK_DATA.images} />
        <CaptionCard 
          caption={MOCK_DATA.caption} 
          hashtags={MOCK_DATA.hashtags} 
        />
      </main>

      <Footer />
    </div>
  );
};

export default App;