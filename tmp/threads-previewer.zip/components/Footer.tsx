import React, { useState } from 'react';
import { AtSign, Loader2 } from 'lucide-react';

export const Footer: React.FC = () => {
  const [isPosting, setIsPosting] = useState(false);

  const handlePost = () => {
    setIsPosting(true);
    // Simulate API call
    setTimeout(() => {
      setIsPosting(false);
      alert("Posted successfully! (Simulation)");
    }, 1500);
  };

  return (
    <footer className="px-4 pb-8 mt-auto w-full max-w-md mx-auto">
      <div className="flex flex-col gap-3">
        <button 
          onClick={handlePost}
          disabled={isPosting}
          className="flex w-full cursor-pointer items-center justify-center rounded-xl h-14 px-6 bg-primary text-black hover:bg-primary-hover active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(19,236,91,0.2)] disabled:opacity-70 disabled:cursor-not-allowed group"
        >
          {isPosting ? (
            <Loader2 className="animate-spin mr-2" size={24} />
          ) : (
            <AtSign className="mr-2 stroke-[2.5]" size={24} />
          )}
          <span className="text-base font-bold tracking-wide">
            {isPosting ? 'Posting...' : 'Post to Threads'}
          </span>
        </button>
        
        <button className="flex w-full cursor-pointer items-center justify-center rounded-xl h-12 px-6 text-gray-500 dark:text-gray-400 font-medium hover:text-gray-900 dark:hover:text-white transition-colors">
          Back to Edit
        </button>
      </div>
    </footer>
  );
};