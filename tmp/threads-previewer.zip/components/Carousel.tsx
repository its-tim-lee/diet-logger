import React from 'react';
import { PostImage } from '../types';

interface CarouselProps {
  images: PostImage[];
}

export const Carousel: React.FC<CarouselProps> = ({ images }) => {
  return (
    <div className="w-full flex overflow-x-auto snap-x snap-mandatory gap-4 px-4 pb-6 no-scrollbar">
      {images.map((img) => (
        <div 
          key={img.id} 
          className="snap-center shrink-0 w-[85%] relative aspect-[4/5] rounded-2xl overflow-hidden shadow-2xl group border border-white/5 bg-surface-dark"
        >
          <div 
            className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
            style={{ 
              backgroundImage: `url('${img.url}')`,
              filter: img.filter 
            }}
            role="img"
            aria-label={img.alt}
          />
        </div>
      ))}
      {/* Spacer to allow the last item to snap correctly in center with padding */}
      <div className="w-1 shrink-0 snap-align-none" /> 
    </div>
  );
};