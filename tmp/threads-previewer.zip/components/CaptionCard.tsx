import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';

interface CaptionCardProps {
  caption: string;
  hashtags: string[];
}

export const CaptionCard: React.FC<CaptionCardProps> = ({ caption, hashtags }) => {
  const [copied, setCopied] = useState(false);

  const fullText = `${caption}\n\n${hashtags.join(' ')}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="px-4 mb-4">
      <div className="relative group/caption">
        <div className="bg-white dark:bg-surface-dark border border-gray-200 dark:border-white/5 rounded-2xl p-5 pr-12 shadow-sm">
          <p className="text-gray-700 dark:text-gray-200 text-sm leading-relaxed font-medium whitespace-pre-line">
            {caption}
            <br />
            <br />
            <span className="text-primary font-semibold">
              {hashtags.join(' ')}
            </span>
          </p>
        </div>
        
        <button 
          onClick={handleCopy}
          aria-label="Copy caption" 
          className="absolute top-3 right-3 p-2 text-gray-400 hover:text-primary hover:bg-primary/10 rounded-lg transition-all"
        >
          {copied ? (
            <Check size={20} className="text-primary" />
          ) : (
            <Copy size={20} />
          )}
        </button>
      </div>
    </div>
  );
};