import React from 'react';

export const PreviewHeader: React.FC = () => {
  return (
    <header className="flex items-center justify-center px-4 py-6 bg-transparent sticky top-0 z-10">
      <h1 className="text-lg font-bold text-gray-900 dark:text-white tracking-tight">Preview</h1>
    </header>
  );
};