export interface PostImage {
  id: string;
  url: string;
  alt: string;
  filter?: string;
}

export interface PostData {
  images: PostImage[];
  caption: string;
  hashtags: string[];
}
